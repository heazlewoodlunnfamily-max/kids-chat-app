const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const cors = require('cors');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

app.use(cors());
app.use(express.json());

let messages = [];

// HTML content embedded directly
const htmlContent = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Friend Chat</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 10px;
        }

        .container {
            width: 100%;
            max-width: 500px;
            background: white;
            border-radius: 20px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
            display: flex;
            flex-direction: column;
            height: 90vh;
            max-height: 800px;
        }

        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 15px;
            border-radius: 20px 20px 0 0;
            text-align: center;
            font-size: 24px;
            font-weight: bold;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header-title {
            flex-grow: 1;
        }

        .connection-status {
            display: flex;
            align-items: center;
            gap: 6px;
            font-size: 12px;
            padding: 4px 8px;
            background: rgba(255,255,255,0.2);
            border-radius: 12px;
        }

        .status-dot {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background: #4caf50;
            animation: pulse 2s infinite;
        }

        .status-dot.disconnected {
            background: #ff5252;
            animation: none;
        }

        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }

        .admin-btn {
            background: rgba(255,255,255,0.2);
            border: none;
            color: white;
            padding: 8px 12px;
            border-radius: 8px;
            cursor: pointer;
            font-size: 14px;
            transition: background 0.3s;
        }

        .admin-btn:hover {
            background: rgba(255,255,255,0.3);
        }

        .user-selector {
            display: flex;
            gap: 8px;
            padding: 12px;
            background: #f0f0f0;
            border-bottom: 2px solid #e0e0e0;
            flex-wrap: wrap;
            justify-content: center;
        }

        .user-btn {
            padding: 10px 16px;
            border: 2px solid #ddd;
            background: white;
            border-radius: 20px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
            transition: all 0.3s;
        }

        .user-btn.active {
            background: #667eea;
            color: white;
            border-color: #667eea;
            transform: scale(1.05);
        }

        .user-btn:hover {
            border-color: #667eea;
        }

        .chat-display {
            flex: 1;
            overflow-y: auto;
            padding: 15px;
            background: #fafafa;
        }

        .message {
            margin-bottom: 12px;
            display: flex;
            flex-direction: column;
            animation: slideIn 0.3s ease-out;
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .message.own {
            align-items: flex-end;
        }

        .message-bubble {
            max-width: 80%;
            padding: 10px 14px;
            border-radius: 16px;
            word-wrap: break-word;
            font-size: 15px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        .message.own .message-bubble {
            background: #667eea;
            color: white;
            border-bottom-right-radius: 4px;
        }

        .message.friend1 .message-bubble {
            background: #ff6b9d;
            color: white;
            border-bottom-left-radius: 4px;
        }

        .message.friend2 .message-bubble {
            background: #4ecdc4;
            color: white;
            border-bottom-left-radius: 4px;
        }

        .message.friend3 .message-bubble {
            background: #ffa502;
            color: white;
            border-bottom-left-radius: 4px;
        }

        .message-sender {
            font-size: 12px;
            color: #999;
            margin: 4px 0;
            font-weight: 600;
        }

        .message.own .message-sender {
            text-align: right;
        }

        .input-area {
            padding: 12px;
            background: white;
            border-top: 2px solid #e0e0e0;
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
            border-radius: 0 0 20px 20px;
        }

        .input-container {
            display: flex;
            gap: 8px;
            flex: 1;
            min-width: 200px;
        }

        .input-field {
            flex: 1;
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 20px;
            font-size: 15px;
            font-family: inherit;
            transition: border-color 0.3s;
        }

        .input-field:focus {
            outline: none;
            border-color: #667eea;
        }

        .send-btn {
            background: #667eea;
            color: white;
            border: none;
            padding: 12px 20px;
            border-radius: 20px;
            font-size: 15px;
            font-weight: bold;
            cursor: pointer;
            transition: background 0.3s, transform 0.1s;
        }

        .send-btn:hover {
            background: #764ba2;
        }

        .send-btn:active {
            transform: scale(0.95);
        }

        .send-btn:disabled {
            background: #ccc;
            cursor: not-allowed;
        }

        .emoji-btn {
            background: #fff;
            border: 2px solid #ffc107;
            padding: 10px 14px;
            border-radius: 16px;
            font-size: 20px;
            cursor: pointer;
            transition: all 0.3s;
        }

        .emoji-btn:hover {
            background: #ffc107;
            transform: scale(1.1);
        }

        .emoji-picker {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 8px;
            padding: 10px;
            background: white;
            border-radius: 12px;
            margin-bottom: 8px;
            border: 2px solid #ffc107;
            max-height: 200px;
            overflow-y: auto;
        }

        .emoji-option {
            font-size: 24px;
            cursor: pointer;
            text-align: center;
            padding: 8px;
            border-radius: 8px;
            transition: background 0.2s;
        }

        .emoji-option:hover {
            background: #fff3cd;
        }

        .admin-panel {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.7);
            display: none;
            z-index: 1000;
            align-items: center;
            justify-content: center;
        }

        .admin-panel.show {
            display: flex;
        }

        .admin-content {
            background: white;
            padding: 20px;
            border-radius: 16px;
            width: 90%;
            max-width: 600px;
            max-height: 80vh;
            overflow-y: auto;
        }

        .admin-header {
            font-size: 20px;
            font-weight: bold;
            margin-bottom: 15px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .close-btn {
            background: #ff6b6b;
            color: white;
            border: none;
            padding: 8px 12px;
            border-radius: 8px;
            cursor: pointer;
            font-weight: bold;
        }

        .admin-messages {
            max-height: 400px;
            overflow-y: auto;
            border: 2px solid #e0e0e0;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 15px;
            background: #fafafa;
        }

        .admin-message-item {
            padding: 10px;
            background: white;
            margin-bottom: 8px;
            border-radius: 8px;
            border-left: 4px solid #667eea;
            font-size: 13px;
        }

        .admin-message-sender {
            font-weight: bold;
            color: #667eea;
        }

        .admin-message-time {
            font-size: 11px;
            color: #999;
            margin-top: 4px;
        }

        .delete-all-btn {
            background: #ff6b6b;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 8px;
            cursor: pointer;
            font-weight: bold;
            width: 100%;
            margin-top: 10px;
        }

        .delete-all-btn:hover {
            background: #ff5252;
        }

        .stats {
            background: #f0f0f0;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 15px;
            font-size: 14px;
        }

        .stats-item {
            margin: 5px 0;
        }

        .loading {
            text-align: center;
            color: #999;
            padding: 20px;
        }

        .spinner {
            border: 3px solid #f3f3f3;
            border-top: 3px solid #667eea;
            border-radius: 50%;
            width: 30px;
            height: 30px;
            animation: spin 1s linear infinite;
            margin: 0 auto 10px;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        @media (max-width: 480px) {
            .message-bubble {
                max-width: 85%;
            }
            
            .input-field {
                font-size: 16px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="header-title">💬 Friend Chat</div>
            <div class="connection-status">
                <div class="status-dot" id="statusDot"></div>
                <span id="statusText">Connecting...</span>
            </div>
            <button class="admin-btn" onclick="toggleAdmin()">📊</button>
        </div>

        <div class="user-selector" id="userSelector"></div>

        <div class="chat-display" id="chatDisplay">
            <div class="loading">
                <div class="spinner"></div>
                Loading messages...
            </div>
        </div>

        <div class="input-area">
            <div id="emojiPicker" class="emoji-picker" style="display: none;"></div>
            <div class="input-container">
                <button class="emoji-btn" onclick="toggleEmojiPicker()">😀</button>
                <input type="text" class="input-field" id="messageInput" placeholder="Type a message..." autocomplete="off" disabled>
                <button class="send-btn" id="sendBtn" onclick="sendMessage()" disabled>Send</button>
            </div>
        </div>
    </div>

    <div class="admin-panel" id="adminPanel">
        <div class="admin-content">
            <div class="admin-header">
                <span>Parent Dashboard</span>
                <button class="close-btn" onclick="toggleAdmin()">Close</button>
            </div>
            
            <div class="stats" id="stats"></div>
            
            <div>
                <strong>All Messages:</strong>
                <div class="admin-messages" id="allMessages"></div>
            </div>
            
            <button class="delete-all-btn" onclick="clearAllMessages()">Clear All Messages</button>
        </div>
    </div>

    <script>
        const USERS = {
            you: { name: 'Esther', color: '#667eea' },
            friend1: { name: 'Valley', color: '#ff6b9d' },
            friend2: { name: 'Amaaya', color: '#4ecdc4' },
            friend3: { name: 'Parent', color: '#ffa502' }
        };

        const EMOJIS = ['😀', '😂', '😍', '🥰', '😎', '🤗', '😭', '😤', '🤔', '🤐', '🤨', '😏', '😬', '🤥', '🙂', '🤓', '😉', '😌', '😔', '😪', '🤤', '😴', '😷', '🤒', '🤕', '🤮', '🤢', '🎉', '🎊', '🎈', '🎁', '🎀', '🎂', '🍰', '🧁', '🍪', '🍩', '🍫', '🍬', '🍭', '🍮', '🍯', '🍕', '🍔', '🍟', '🌭', '🍿', '☕', '🧋', '🥤', '🍹', '🍸', '👍', '👏', '🙌', '🤲', '🤝', '💅', '👶', '👧', '🧒', '👦', '👨', '👩', '🎨', '🎭', '🎪', '🎬', '🎤', '🎧', '🎼', '🎹', '🎸', '🎺', '🎷', '🥁', '🎻', '🎲', '🎯', '🎳', '🎮', '🚗', '🚕', '🚙', '🚌', '🚎', '🏎️', '🚓', '🚑', '🚒', '🚐', '🛻', '🚚', '🚛', '🚜', '🏍️', '✈️', '🛩️', '🛫', '🛬', '🚁', '🛶', '⛵', '🚤', '🛳️', '🛥️', '🚢', '⛴️', '🚀', '🛸', '🌟', '⭐', '✨', '💫', '⚡', '☄️', '💥', '🔥', '🌈', '☀️', '🌤️', '⛅', '🌥️', '☁️', '🌦️', '🌧️', '⛈️', '🌩️', '🌨️', '❄️', '☃️', '🌬️', '💨', '💧', '💦', '🐱', '🐶', '🐭', '🐹', '🐰', '🦊', '🐻', '🐼', '🐨', '🐯', '🦁', '🐮', '🐷', '🐽', '🐸', '🐵', '🙈', '🙉', '🙊', '🐒', '🐔', '🐧', '🐦', '🐤', '🦆', '🦅', '🦉', '🦇'];

        let currentUser = 'you';
        let messages = [];
        let showEmojiPicker = false;
        let ws = null;
        let isConnected = false;

        function getWebSocketURL() {
            const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
            return \`\${protocol}//\${window.location.host}\`;
        }

        function init() {
            renderUserButtons();
            renderEmojiPicker();
            setupEventListeners();
            connectWebSocket();
        }

        function connectWebSocket() {
            try {
                ws = new WebSocket(getWebSocketURL());

                ws.onopen = () => {
                    isConnected = true;
                    updateConnectionStatus(true);
                    document.getElementById('messageInput').disabled = false;
                    document.getElementById('sendBtn').disabled = false;
                };

                ws.onmessage = (event) => {
                    const data = JSON.parse(event.data);
                    
                    if (data.type === 'load_messages') {
                        messages = data.messages;
                        renderChat();
                    } else if (data.type === 'message') {
                        messages.push(data.data);
                        renderChat();
                        setTimeout(() => {
                            document.getElementById('chatDisplay').scrollTop = document.getElementById('chatDisplay').scrollHeight;
                        }, 0);
                    } else if (data.type === 'messages_cleared') {
                        messages = [];
                        renderChat();
                    }
                };

                ws.onerror = () => {
                    updateConnectionStatus(false);
                };

                ws.onclose = () => {
                    isConnected = false;
                    updateConnectionStatus(false);
                    document.getElementById('messageInput').disabled = true;
                    document.getElementById('sendBtn').disabled = true;
                    setTimeout(connectWebSocket, 3000);
                };
            } catch (error) {
                setTimeout(connectWebSocket, 3000);
            }
        }

        function updateConnectionStatus(connected) {
            const dot = document.getElementById('statusDot');
            const text = document.getElementById('statusText');
            
            if (connected) {
                dot.classList.remove('disconnected');
                text.textContent = 'Connected';
            } else {
                dot.classList.add('disconnected');
                text.textContent = 'Reconnecting...';
            }
        }

        function setupEventListeners() {
            document.getElementById('messageInput').addEventListener('keypress', (e) => {
                if (e.key === 'Enter') sendMessage();
            });
        }

        function renderUserButtons() {
            const selector = document.getElementById('userSelector');
            selector.innerHTML = '';
            Object.keys(USERS).forEach(userId => {
                const btn = document.createElement('button');
                btn.className = \`user-btn \${userId === currentUser ? 'active' : ''}\`;
                btn.textContent = USERS[userId].name;
                btn.onclick = () => switchUser(userId);
                selector.appendChild(btn);
            });
        }

        function switchUser(userId) {
            currentUser = userId;
            renderUserButtons();
            document.getElementById('messageInput').focus();
        }

        function renderEmojiPicker() {
            const picker = document.getElementById('emojiPicker');
            picker.innerHTML = '';
            EMOJIS.forEach(emoji => {
                const btn = document.createElement('div');
                btn.className = 'emoji-option';
                btn.textContent = emoji;
                btn.onclick = () => addEmoji(emoji);
                picker.appendChild(btn);
            });
        }

        function toggleEmojiPicker() {
            showEmojiPicker = !showEmojiPicker;
            document.getElementById('emojiPicker').style.display = showEmojiPicker ? 'grid' : 'none';
        }

        function addEmoji(emoji) {
            const input = document.getElementById('messageInput');
            input.value += emoji;
            input.focus();
        }

        function sendMessage() {
            if (!isConnected) {
                alert('Not connected. Please wait...');
                return;
            }

            const input = document.getElementById('messageInput');
            const text = input.value.trim();

            if (!text) return;

            const message = {
                type: 'new_message',
                user: currentUser,
                text: text
            };

            ws.send(JSON.stringify(message));
            input.value = '';
            showEmojiPicker = false;
            document.getElementById('emojiPicker').style.display = 'none';
        }

        function renderChat() {
            const display = document.getElementById('chatDisplay');
            display.innerHTML = '';

            if (messages.length === 0) {
                display.innerHTML = '<div style="text-align: center; color: #999; padding: 20px; font-size: 16px;">No messages yet. Start chatting! 💬</div>';
                return;
            }

            messages.forEach(msg => {
                const div = document.createElement('div');
                div.className = \`message \${msg.user}\`;
                div.innerHTML = \`
                    <div class="message-sender">\${USERS[msg.user].name}</div>
                    <div class="message-bubble">\${escapeHtml(msg.text)}</div>
                \`;
                display.appendChild(div);
            });

            display.scrollTop = display.scrollHeight;
        }

        function toggleAdmin() {
            const panel = document.getElementById('adminPanel');
            panel.classList.toggle('show');
            if (panel.classList.contains('show')) {
                renderAdminPanel();
            }
        }

        function renderAdminPanel() {
            const statsDiv = document.getElementById('stats');
            const msgDiv = document.getElementById('allMessages');

            statsDiv.innerHTML = \`
                <div class="stats-item"><strong>Total Messages:</strong> \${messages.length}</div>
                <div class="stats-item"><strong>Connected Users:</strong> 4</div>
                <div class="stats-item"><strong>Status:</strong> \${isConnected ? '🟢 Connected' : '🔴 Disconnected'}</div>
            \`;

            msgDiv.innerHTML = '';
            messages.slice().reverse().forEach(msg => {
                const div = document.createElement('div');
                div.className = 'admin-message-item';
                div.innerHTML = \`
                    <div><span class="admin-message-sender">\${USERS[msg.user].name}:</span> \${escapeHtml(msg.text)}</div>
                    <div class="admin-message-time">\${msg.date} at \${msg.timestamp}</div>
                \`;
                msgDiv.appendChild(div);
            });
        }

        function clearAllMessages() {
            if (confirm('Are you sure you want to delete all messages? This cannot be undone.')) {
                fetch('/api/admin/clear', { method: 'POST' });
            }
        }

        function escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }

        init();
    </script>
</body>
</html>\`;

// Serve the HTML
app.get('/', (req, res) => {
    res.send(htmlContent);
});

// REST API
app.get('/api/messages', (req, res) => {
    res.json(messages);
});

// WebSocket handling
wss.on('connection', (ws) => {
    console.log('Client connected');

    ws.send(JSON.stringify({
        type: 'load_messages',
        messages: messages
    }));

    ws.on('message', (data) => {
        try {
            const message = JSON.parse(data);
            
            if (message.type === 'new_message') {
                const newMsg = {
                    id: Date.now(),
                    user: message.user,
                    text: message.text,
                    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                    date: new Date().toLocaleDateString()
                };
                
                messages.push(newMsg);

                broadcast({
                    type: 'message',
                    data: newMsg
                });
            }
        } catch (error) {
            console.error('Error:', error);
        }
    });

    ws.on('close', () => {
        console.log('Client disconnected');
    });
});

function broadcast(message) {
    const data = JSON.stringify(message);
    wss.clients.forEach((client) => {
        if (client.readyState === WebSocket.OPEN) {
            client.send(data);
        }
    });
}

app.post('/api/admin/clear', (req, res) => {
    messages = [];
    broadcast({ type: 'messages_cleared' });
    res.json({ success: true });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
